﻿using System.ComponentModel.DataAnnotations;

namespace MLWebClient.Models
{
    public class TimeSeriesViewModel
    {
        [Required]
        [Range(1, 36)]
        public int? Month { get; set; }
        public string? Rainfall { get; set; }
    }
}
