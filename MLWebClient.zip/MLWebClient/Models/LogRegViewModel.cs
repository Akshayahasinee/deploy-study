﻿using System.ComponentModel.DataAnnotations;

namespace MLWebClient.Models
{
    public class LogRegViewModel
    {
        [Required]
        [Range(0.0, 1000.00)]
        public double? Height { get; set; }
        [Required]
        [Range(0.0, 1000.00)]
        public double? Weight { get; set; }
        public string? Gender { get; set; }
    }
}
