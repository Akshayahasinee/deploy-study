using Microsoft.AspNetCore.Diagnostics;

namespace MLWebClient.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

        public IExceptionHandlerPathFeature? exceptionHandlerPathFeature { get; set; }

        public string? Path { get; set; }
    }
}