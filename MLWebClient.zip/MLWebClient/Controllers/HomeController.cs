﻿using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MLWebClient.Models;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace MLWebClient.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }


        public IActionResult Regression()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Regression(LogRegViewModel model)
        {

            if(ModelState.IsValid)
            {
                string? height = model.Height.ToString();
                string? weight = model.Weight.ToString();
                double pH;
                double pW;

                if (!string.IsNullOrEmpty(height) || !string.IsNullOrEmpty(weight))
                    if (double.TryParse(height, out pH) && double.TryParse(weight, out pW))
                        model.Gender = GetModelResult("logreg", pH, pW).Result;

                return View(model);
            }

            return View();
        }

        public IActionResult TimeSeries()
        {
            return View();
        }

        [HttpPost]
        public IActionResult TimeSeries(TimeSeriesViewModel model)
        {

            if (ModelState.IsValid)
            {
                string? month = model.Month.ToString();
                double pM;

                if (!string.IsNullOrEmpty(month))
                    if (double.TryParse(month, out pM))
                        model.Rainfall = GetModelResult("timeseries", pM, -1).Result;

                return View(model);
            }

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            var exceptionHandlerPathFeature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
            var path = exceptionHandlerPathFeature?.Path;

            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier, 
                exceptionHandlerPathFeature = exceptionHandlerPathFeature, Path = path });
        }

        public async Task<string> GetModelResult(string modelPath, double xValue, double yValue)
        {
            UriBuilder uriBuilder = new UriBuilder();
            uriBuilder.Scheme = "http";
            uriBuilder.Host = "localhost";
            uriBuilder.Path = modelPath;
            uriBuilder.Port = 8080;
            if(yValue == -1)
                uriBuilder.Query = "x=" + xValue;
            else
                uriBuilder.Query = "x=" + xValue + "&y=" + yValue;

            var data = "";

            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(uriBuilder.ToString());
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/text"));


                HttpResponseMessage response = await client.GetAsync(uriBuilder.ToString());
                if (response.IsSuccessStatusCode)
                {
                    data = await response.Content.ReadAsStringAsync();
                }

            }
            return data;

        }
    }
}